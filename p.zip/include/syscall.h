//
// Created by root on 2020/11/9.
//

#ifndef SYSCALL_H
#define SYSCALL_H
#include "types.h"
#include "interrupt.h"



#endif
