#ifndef _8259A_C
#define _8259A_C
void _8259A_init();
#endif