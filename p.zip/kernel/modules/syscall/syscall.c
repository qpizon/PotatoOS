//
// Created by root on 2020/11/9.
//

#include "syscall.h"

void interrupt_handler_syscall(){

}

void syscall_init(){
    
}
