#ifndef INIT_H
#define INIT_H
void idt_init();
void pmm_init();
void threads_init();
#endif